var w = 400, h = 625;
var game = new Phaser.Game( w, h, Phaser.CANVAS, '');

var basicGame = function(){

}